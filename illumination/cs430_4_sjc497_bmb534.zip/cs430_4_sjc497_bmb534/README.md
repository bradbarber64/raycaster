# Authors:
Bradley Barber (bmb534@nau.edu) and Savannah Chappus (sjc497@nau.edu)
# Usage:
raycast width height input.txt output.ppm
# Known Issues: 
1. If an object is missing attributes the code doesn't support it well
2. Code renders scene file roughly 90% correctly. Something is off in the lighting equation but we have yet to pinpoint where exactly the error is. 
