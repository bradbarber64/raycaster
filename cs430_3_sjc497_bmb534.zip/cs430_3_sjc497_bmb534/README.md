# Authors: Bradley Barber (bmb534@nau.edu) and Savannah Chappus (sjc497@nau.edu)
# Usage: raycast width height input.txt output.ppm
# Known Issues: None
